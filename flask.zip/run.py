from flask import Flask, request, session, g, redirect, url_for,    abort, render_template, flash
from db import *

DEBUG = True
SECRET_KEY = 'development key'


app = Flask(__name__)
app.config.from_object(__name__)


@app.route('/')
def home_page():
    qsession = get_session()
    entries = qsession.query(blogtable).all()

    return render_template('home.html', entries=entries)


@app.route('/mange')
def manage():
    qsession = get_session()
    entries = qsession.query(blogtable).filter_by(userid=session['cur_user_id']).all()
    return render_template('about.html', entries=entries)


@app.route('/comment/<int:blogid>', methods=['GET', 'POST'])
def comment(blogid):
    com = commenttable(
        blogid=blogid,
        comment_by_name=session['cur_name'],
        comment_text=request.form['text']
    )
    qsession = get_session()
    qsession.add(com)
    qsession.commit()
    return redirect(url_for('show_blog', blogid=blogid))


@app.route('/del_blog/<int:blogid>')
def del_blog(blogid):
    qsession = get_session()
    blog = qsession.query(blogtable).filter_by(blogid=blogid).first()
    qsession.delete(blog)
    qsession.commit()
    return redirect(url_for('home_page'))


@app.route('/edit_blog/<int:blogid>', methods=['GET', 'POST'])
def edit_blog(blogid):
    qsession = get_session()
    blog = qsession.query(blogtable).filter_by(blogid=blogid).first()
    if request.method == 'POST':
        blog.title = request.form['title']
        blog.text = request.form['text']
        qsession.commit()
        return redirect(url_for('home_page'))
    return render_template('post.html', blog=blog)


@app.route('/<int:blogid>', methods=['GET'])
def show_blog(blogid):
    qsession = get_session()
    blog = qsession.query(blogtable).filter_by(blogid=blogid).first()
    comments = qsession.query(commenttable).filter_by(blogid=blogid).all()
    return render_template('show_blog.html', post=blog, comments=comments)


def add_blog(userid, title, text):
    blog = blogtable(
        userid=userid,
        title=title,
        text=text
    )
    qsession = get_session()
    qsession.add(blog)
    qsession.commit()


@app.route('/publish', methods=['GET', 'POST'])
def publish():
    if request.method == 'POST':
        userid = session['cur_user_id']
        title = request.form['title']
        text = request.form['text']

        add_blog(userid, title, text)

    return redirect(url_for('home_page'))


def add_user(email, username, password):
    user = usertable(
        name=username,
        passwd=password,
        email=email
    )
    qsession = get_session()
    qsession.add(user)
    qsession.commit()


@app.route('/register', methods=['GET', 'POST'])
def register():
    error = None
    qsession = get_session()
    if request.method == 'POST':
        username = request.form['first_name_new']
        email = request.form['email_new']
        password = request.form['password_new']
        passwordConfirm = request.form['password_confirm']
        user = qsession.query(usertable).filter_by(name=username).first()
        if user is not None:
            flash('Username already exist. Please choose a different one.')
            return redirect(url_for('register'))
        elif password != passwordConfirm:
            flash('Passwords do not match. Please try again.')
            return redirect(url_for('register'))
        else:
            add_user(email, username, password)
            flash('Thanks for registering with us!')
            return redirect(url_for('home_page'))
    return render_template('register.html', error=error)


@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        qsession = get_session()

        email = request.form['username']
        query = qsession.query(usertable).filter_by(email=email).first()
        if query is not None:
            if query.passwd != request.form['password']:
                if (request.form['password'] == '') :
                    flash('Passwords is None. Please try again.')
                    return render_template('login.html', error=error)
                else:
                    flash('Passwords do not match. Please try again.')
                    return render_template('404.html', error=error)
            else:
                session['logged_in'] = True
                session['cur_email'] = email
                session['cur_name'] = query.name
                session['cur_user_id'] = query.userid
                flash('you were logged in')
                return redirect(url_for('home_page'))
        else:
            error = 'Invalid email. Please check.'
    return render_template('login.html', error=error)


@app.route('/logout', methods=['GET'])
def logout():
    session.pop('logged_in', None)
    session['cur_user_id'] = None
    flash('You have been logged out.')
    return redirect(url_for('home_page'))


if __name__ == '__main__':
    app.run()
